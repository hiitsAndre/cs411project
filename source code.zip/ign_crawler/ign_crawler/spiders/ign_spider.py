# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request
from scrapy.selector import Selector
import os

class IGNItem(scrapy.Item):
    title = scrapy.Field()
    platform = scrapy.Field()
    release_date = scrapy.Field()
    score = scrapy.Field()
    genre = scrapy.Field()

BASE_REQUEST = "http://www.ign.com/games?"
N_GAMES = 100
N_GENRES = 27

def save_body(bd,fn):
    with open(fn,'wt') as f:
        f.write(bd)

class IgnSpider(scrapy.Spider):
    name = "ign"
    allowed_domains = ["http://www.ign.com","ign.com"]
    start_urls = (
            "http://www.ign.com/games",
    )

    def parse(self, response):
        for i in range(N_GENRES):
            genre = response.css("option.genre::attr(value)")[i].get()
            next_request = BASE_REQUEST + "genre=" + genre
            yield Request(next_request, callback=self.parse_games, meta = {'genre' : genre})

    def parse_games(self, response):
        genre_link = response.url + "&sortBy=releaseDate&sortOrder=desc&startIndex="
        n_loops = N_GAMES/50

        for i in range(n_loops):
            next_request = genre_link + str(50*i)
            yield Request(next_request, callback=self.parse_details, meta = {'genre' : response.meta['genre']})

    def parse_details(self,response):
        item_nodes = Selector(response, type='html').xpath('//div[@class="clear itemList-itemShort"]')

        if len(item_nodes) != 50:
            print len(item_nodes)

        for node in item_nodes:
            item = IGNItem()
            title_node = node.css('div.item-title')
            title = title_node.xpath('a/text()').extract_first()
            item['title'] = title.strip()
            item['platform'] = title_node.xpath('span/text()').extract_first()
            item['genre'] = response.meta['genre']
            item['release_date'] = node.xpath('.//div[@class="releaseDate grid_3 omega"]/text()').extract_first().strip()
            item['score'] = node.xpath('.//div[@class="grid_3"]/text()').extract_first().strip()

            yield item
