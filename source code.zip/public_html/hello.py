#!/usr/bin/env bash

import sys
import os
dir_path = os.path.dirname(os.path.realpath(__file__))
print(dir_path)


source /home/gamerskii/virtualenv/public__html_python__app/2.7/bin/activate
python /home/gamerskii/public_html/pages/test.py

print 'Hello world just kidding fffffff'
print 'Argument List:', sys.argv
