<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$id = $_GET["id"];
$pwd = $_GET["psw"];



$sql = "select * from login_info where id = '$id' and pwd = '$pwd'";
$result = $conn->query($sql);
if ($result->num_rows > 0){
    header("Location: personal_page.php?uid=$id");
    exit();
    //echo "welcome to gamerbois\n";
    //$url = "../logged_in.php?uid='$id'";
    //echo "<a href=$url>Back</a>";
    
}

else{
    echo "wrong passord, retry please\n";
    echo "<a href='../index.php'>Retry</a>";
}
$conn->close();
?>