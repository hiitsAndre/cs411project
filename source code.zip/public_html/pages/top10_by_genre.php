<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);
$userid =  $_GET["uid"];

if($userid == NULL){
    $backurl = "../index.php" ;
}
else{
    $backurl = "../index.php?uid=$userid" ;
}


//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$platforms = $conn->query("select distinct platform, count(*) as c from metacritic group by platform order by count(*) desc limit 5");
$genre = $_GET["genre"];

echo "<p><font size='6pt'>Top 10 games for popular platforms of genre \"$genre\"</font></p>";
echo "<!DOCTYPE html>
        <html>
            <head>
                <link rel='stylesheet' href='css/style.css'>
                <style>
                    table, th, td {
                      border: 1px solid black;
                      margin: 0px auto;
                    }
                </style>
            </head>
        
        <body>
            <title>Search Result</title>
        
            <div class='topnav'>
              <a href=$backurl>Back</a>
            </div>";

while($p = $platforms->fetch_assoc()){
    $plat = $p['platform'];
    $result = $conn->query("select M.name, M.metascore, M.release_date from (select * from metacritic where genre like '%$genre%' and platform = '$plat' order by metascore desc limit 10) as M left join ign I on I.game = M.name and I.platform = M.platform order by M.metascore desc");
    if ($result->num_rows > 0){
        echo "<p align=center>". $plat. "</p>";
        echo "<table>";
        echo "<th>". "Name". "</th>". "<th>". "Metascore". "</th>". "<th>". "Launch Date". "</th>". "\n";
    	  
    	while($row = $result->fetch_assoc()){
    	    echo "<tr>";
    		echo "<th>". $row["name"]. "</th>". "<th>". $row["metascore"]. "</th>". "<th>". $row["release_date"]. "</th>". "\n";
    	    echo "</tr>";
    	}
    	echo "</table>";
    }
    else{
    	echo "No games on ". $plat. " of genre ". $genre. "<br>";
    }
}

echo "</body>
</html>";
$conn->close();
?>
