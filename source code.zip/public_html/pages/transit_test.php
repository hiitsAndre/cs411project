<?php
ini_set('short_open_tag', 'on');
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}



$name = $_GET["name"];
$userid = $_GET["uid"];
$game1 = $_GET["game1"];
$game2 = $_GET["game2"];
$game3 = $_GET["game3"];
$game4 = $_GET["game4"];
$game5 = $_GET["game5"];
$platform1 = $_GET["platform1"];
$platform2 = $_GET["platform2"];
$platform3 = $_GET["platform3"];
$platform4 = $_GET["platform4"];

$recomendurl = "recommend.php?uid=$userid";
$g1time = $_GET["g1time"];
$g2time = $_GET["g2time"];
$g3time = $_GET["g3time"];
$g4time = $_GET["g4time"];
$g5time = $_GET["g5time"];

$g1platform = $_GET["g1platform"];
$g2platform = $_GET["g2platform"];
$g3platform = $_GET["g3platform"];
$g4platform = $_GET["g4platform"];
$g5platform = $_GET["g5platform"];
if($userid == NULL){
    $backurl = '../index.php';
}
else{
     $backurl = "../index.php?uid=$userid";
     
}
echo "<!DOCTYPE html>
				<html>
				    <head>
				       <link rel='stylesheet' href='css/style.css'>
				    </head>


				<body>
				    

				    <title class='mainTitle'>Gamerskii</title>

                    
				    <div class='topnav'>
				        <a class='active' href=''#home'>Home</a>
				    </div>
				    <div class='topnav'>
    				    <form action='recommend.php' method='get'>
    				        <input type='hidden' name='uid' value=$userid />
    				        <a class='email'>
    				        <h4>Games Played</h4>
        				    <input type='text' placeholder='g1' name='game1'/>
        				    <input type='text' placeholder='g2' name='game2'/>
        				    <input type='text' placeholder='g3' name='game3'/>
        				    <input type='text' placeholder='g4' name='game4'/>
        				    <input type='text' placeholder='g5' name='game5'/>
        				    </a>
        				    <br>
        				    
        				    
        				    <a>
        				    <h4>Games' Platforms</h4>
        				    <input type='text' placeholder='g1platform' name='g1platform'/>
        				    <input type='text' placeholder='g2platform' name='g2platform'/>
        				    <input type='text' placeholder='g3platform' name='g3platform'/>
        				    <input type='text' placeholder='g4platform' name='g4platform'/>
        				    <input type='text' placeholder='g5platform' name='g5platform'/>
        				    </a>
        				    <br>
        				    
        				    <a>
        				    <h4>Games' played time</h4>
        				    <input type='text' placeholder='g1playtime' name='g1time'/>
        				    <input type='text' placeholder='g2playtime' name='g2time'/>
        				    <input type='text' placeholder='g3playtime' name='g3time'/>
        				    <input type='text' placeholder='g4playtime' name='g4time'/>
        				    <input type='text' placeholder='g5playtime' name='g5time'/>
        				    </a>
        				    <br>
        				    
        				    <a>
        				    <h4>Platforms owned</h4>
        				    <br>
        				    <input type='text' placeholder='p1' name='platform1' />
        				    <input type='text' placeholder='p2' name='platform2'/>
        				    <input type='text' placeholder='p3' name='platform3'/>
        				    <input type='text' placeholder='p4' name='platform4'/>
        				    <input type='submit' name='submit' />
        				    </a>
    				    </form>
				    </div>
				    
				    
				    
";

echo "
<body>
</html>";
$conn->close();
?>