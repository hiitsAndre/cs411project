#!/usr/bin/env python
import sys
print 'Hello world just kidding dddd'

print 'Argument List:', sys.argv[1],sys.argv[2]