<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

$userid =  $_GET["uid"];

if($userid == NULL){
    $backurl = "games.php" ;
}
else{
    $backurl = "games.php?uid=$userid" ;
}


//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$name = $_GET["name"];
$metascore = $_GET["metascore"];
$ign_score = $_GET["ign_score"];
$platform = $_GET["platform"];
$genre = $_GET["genre"];
$date = $_GET["date"];
$publisher = $_GET["publisher"];
// echo "('$name', '$platform', $score, '$date')";
// echo "('$name', '$platform', '$date', '$genre', '$metascore')";
mysqli_query($conn, "insert into ign (game, platform, release_date, score) values ('$name', '$platform', '$date', '$ign_score')");
mysqli_query($conn, "insert into metacritic (name, platform, release_date, genre, publisher, metascore) values ('$name', '$platform', '$date', '$genre', '$publisher', '$metascore')");
$sql = "select M.name, M.platform, M.metascore, M.genre, M.publisher, M.link, I.score, M.release_date, M.publisher from metacritic M left join ign I on M.name = I.game and M.platform = I.platform where M.name = '$name' ";
$result = $conn->query($sql);

echo "<!DOCTYPE html>
<html>
    <head>
        <link rel='stylesheet' href='../css/style.css'>
        <style>
        table, th, td {
          border: 1px solid black;
        }
        </style>
    </head>


    <body>
        <title>Search Result</title>
    
        <div class='topnav'>
          <a href=$backurl>Back</a>
        </div>";
    
    echo "Insertion successful. Result is show below.\n";
    
    echo "<table>";
    echo "<th>". "Name". "</th>". "<th>". "Platform". "</th>". "<th>". "Metascore". "</th>". "<th>". "IGN Score". "</th>". "<th>". "Genres". "</th>". "<th>". "Launch Date". "</th>". "<th>". "Publisher". "</th>". "\n";
    
    if ($result->num_rows > 0){
    	while($row = $result->fetch_assoc()){
    	    echo "<tr>";
    		echo "<th>". $row["name"]. "</th>". "<th>". $row["platform"]. "</th>". "<th>". $row["metascore"]. "</th>". "<th>". $row["score"]. "</th>". "<th>". $row["genre"]. "</th>". "<th>". $row["release_date"]. "</th>". "<th>". $row["publisher"]. "</th>". "\n";
	        echo "</tr>";
    	}
    }
    else{
    	echo "no result\n";
    }
    
    echo "</table>";
    
echo "</body></html>";
$conn->close();
?>