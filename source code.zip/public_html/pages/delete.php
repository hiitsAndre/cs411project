<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

$userid =  $_GET["uid"];

if($userid == NULL){
    $backurl = "games.php" ;
}
else{
    $backurl = "games.php?uid=$userid" ;
}


//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

echo "<!DOCTYPE html>
        <html>
            <head>
                <link rel='stylesheet' href='../css/style.css'>
                <style>
                    table, th, td {
                      border: 1px solid black;
                      margin: 0px auto;
                    }
                </style>
            </head>
        
        <body>
            <title>Search Result</title>
        
            <div class='topnav'>
              <a href=$backurl>Back</a>
            </div>";

$name = $_GET["name"];
$platform = $_GET["platform"];
$sql = "select * from metacritic where name = '$name' and platform = '$platform' ";
$search_result = $conn->query($sql);

if ($search_result->num_rows > 0){
    mysqli_query($conn, "delete from ign where game = '$name' and platform = '$platform'");
    mysqli_query($conn, "delete from metacritic where name = '$name' and platform = '$platform'");
    echo "Records successfully deleted";
}
else{
	echo "No results of \"". $name. "\" at \"". $platform."\"\n";
}

echo "</body>
</html>";
$conn->close();
?>