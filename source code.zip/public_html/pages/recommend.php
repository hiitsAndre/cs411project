<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";
//$udata_servername = "localhost";
//$udata_username = "gamerskii_root";
//$udata_password = "458458shanghai";
//$udata_dbname = "gamerskii_user";

$conn = new mysqli($servername, $username, $password, $dbname);
//connect
//$gdata_conn = new mysqli($gdata_servername, $gdata_username, $gdata_password, //$gdata_dbname);
//$udata_conn = new mysqli($udata_servername, $udata_username, $udata_password, //$udata_dbname);
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}
//test
//if ($gdata_conn->connect_error){
//	die("failed". $gdata_conn->connect_error);
//}

// user_plays(id, game, game time)
// user_info(id, platform)

// algo:
// 	id = scanf()
// 	game_t = select game from user_plays where id = id
// 	game_genre = select genre from game_t join ign on gamename


$userid = $_GET["uid"];

if($userid == NULL){
    $backurl = '../index.php';
}
else{
     $backurl = "../index.php?uid=$userid";
     
}
$sql = "select * from ign I left join metacritics M on I.game = M.name and I.platform = M.platform where I.game = '$name'";
$result = $conn->query($sql);

$game1 = $_GET["game1"];
$game2 = $_GET["game2"];
$game3 = $_GET["game3"];
$game4 = $_GET["game4"];
$game5 = $_GET["game5"];

$platform1 = $_GET["platform1"];
$platform2 = $_GET["platform2"];
$platform3 = $_GET["platform3"];
$platform4 = $_GET["platform4"];

$g1time = $_GET["g1time"];
$g2time = $_GET["g2time"];
$g3time = $_GET["g3time"];
$g4time = $_GET["g4time"];
$g5time = $_GET["g5time"];

$g1platform = $_GET["g1platform"];
$g2platform = $_GET["g2platform"];
$g3platform = $_GET["g3platform"];
$g4platform = $_GET["g4platform"];
$g5platform = $_GET["g5platform"];

echo "<!DOCTYPE html>
				<html>
				    <head>
				       <link rel='stylesheet' href='css/style.css'>
				    </head>


				<body>
				    

				    <title class='mainTitle'>Gamerskii</title>


				    ";

//function call below:::::



echo "</body>
</html>";
/*
echo "P1:";
echo $platform1;
echo " P2:";
echo $platform2;
echo " P3:";
echo $platform3;
echo " P4:";
echo $platform4;
*/
echo "<b>User Info Updated!</b>
      <br>";
      
echo "<b>logged in as: " . $userid."</b>";
echo "<a href=personal_page.php?uid=$userid> Return To Personal Page</a>
<br>";

echo "<a href='index.php'>Logout</a>";


$outputUserGamePlay = passthru("python /home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/write_to_user_played.py '$userid' '$game1' '$game2' '$game3' '$game4' '$game5' '$g1platform' '$g2platform' '$g3platform' '$g4platform' '$g5platform' '$g1time' '$g2time' '$g3time' '$g4time' '$g5time'");
echo $outputUserGamePlay;

$outputPlatform = passthru("python /home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/write_to_user_info.py '$userid' '$platform1' '$platform2' '$platform3' '$platform4'");
echo $outputPlatform;

$outputNaive = passthru("python test.py '$userid' '$game1' '$game2'");
echo $outputNaive;

$outputGG = passthru("python /home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/recommend_algo.py '$userid'");
echo $outputGG;

/*shell_exec("source ./home/gamerskii/virtualenv/public__html_python__app/2.7/bin/activate && python ./home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/recommend_algo.py && python ./home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/hello.py" );
*/
//$output2 = passthru("python home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/recommend_algo.py");
//$output = passthru("python home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/hello.py $arg1 $game1 $game2");


//echo $output;
//echo $output2;

$conn->close();


//$gdata_conn->close();
//$udata_conn->close();
?>
