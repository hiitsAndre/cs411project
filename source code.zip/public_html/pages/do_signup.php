<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$id = $_GET["id"];
$pwd = $_GET["psw"];


$sql = "select * from login_info where id = '$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0){
    echo "duplicate user id, please try again";
    echo "<a href='../index.php'>Back</a>";
}
else{
mysqli_query($conn, "insert into login_info (id, pwd) values ('$id','$pwd')");

echo  "sign up succuessful";
echo "<a href='../index.php'>Back</a>";
}
$conn->close();
?>