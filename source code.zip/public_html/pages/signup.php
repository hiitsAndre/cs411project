<!DOCTYPE html>
<html>
    <head>
       <link rel="stylesheet" href="../css/style.css">
    </head>

<body>
    <title class="signupTitle">GamerSkii</title>

    <div class="topnav">
      <a href="../index.php">Back</a>
    </div>
    <!--
        <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Sign Up</button>
    -->
<div id="id01" class="modal">
    <!--
    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    -->
    <form class="modal-content" action="do_signup.php">
    <div class="container">
        <h2>Create Your Account</h2>
        
        <div class="emails">
            <a class="email"><!--<label for="email"><b>userid</b></label>-->
            <input type="text" placeholder="Username" name="id" required>
            </a>
            
            <a class="password"><!--<label for="psw"><b>Password</b></label>-->
            <input type="password" placeholder="Password" name="psw" required>
            </a>
            
            <a class="clearfix">
                <button type="submit" class="signupbtn">Sign Up</button>
            </a>
        </div>

    </div>
    </form>
</div>
</body>
</html>