<?php
ini_set('short_open_tag', 'on');
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}



$name = $_GET["name"];
$userid = $_GET["uid"];
$sql = "select game, time from user_played WHERE id = '$userid' ORDER BY time DESC LIMIT 5";
$info_sql = "select * from user_info where id = '$userid'";
$result = $conn->query($sql);
$info_result = $conn->query($info_sql);
$backurl = "../index.php?uid=$userid";
$transiturl = "transit_test.php?uid=$userid";

$timearray = array("","","","");
$time = array("","","","");
$gamearray = array("","","","");

$namearray = array("game0","game1","game2","game3","game4");
$colorarray = array("#7FFF00","#DC143C","#6495ED","#FF69B4","#FFD700");

if ($result->num_rows > 0){
        
        $index = 0;
        while($row = $result->fetch_assoc()){
            if($index ==0){$max_time =$row["time"];}
            $gamearray[$index] = $row["game"];
            $timearray[$index] = (string)((int)($row["time"]/$max_time*100));
            $time[$index] = (string)($row["time"]);
            $index+=1;
    	}
    }
    


//<a href='pages/signup.php'>Sign Up</a>
echo "<!DOCTYPE html>
				<html>
				    <head>
				       <link rel='stylesheet' href='../css/style.css'>
				    </head>
				    
				    
                <style>
                /* Make sure that padding behaves as expected */
* {box-sizing:border-box}

/* Container for skill bars */
.container {
    position: relative;
    //text-align: right;
    width: 50%; /* Full width */
    background-color: #ddd; /* Grey background */
    height: 50px;
    margin-top: 10px;
    margin-bottom: 10px;
    margin-left: 30px;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}

.game_time {
    position: absolute;
    top: 10px;
    right: 8px;
    //padding-left: 170px;
    line-height: 30px;
    color: black;
    font-family: impact;
    font-style: italic;
    font-size: 27px;
}

.game_name {
    position: absolute;
    top: 10px;
    left: 8px;
    //padding-left: 5px;
    line-height: 30px;
    color: black;
    font-family: impact;
    font-style: italic;
    font-size: 27px;
}

p{
    margin-left : 30px
}

table, td {
    position: absolute;
    right: 50px;
    top: 200px;
    border: 1px solid black;
    margin: 0px auto;
}

th{
    border: 1px solid black;
    margin: 0px auto;
}
";

for($i = 0; $i < 5; $i++){
    echo ".". $namearray[$i];
    echo " {width: ". $timearray[$i]. "%;";
    echo "background-color: ". $colorarray[$i]. ";";
    echo "height: 50px;
          margin-bottom: 10px;
          border-top-right-radius: 4px;
          border-bottom-right-radius: 4px;
    }\n";
}

echo "
    </style>
    
        <body>
            <title class='mainTitle'>GamerSkii</title>
    
            <div class='topnav'>
                <a href=$backurl>Home</a>
			</div>
			<div>
			    <p><font size='6pt' margin-left=30px>Games played</font></p>\n
			</div>";
for($i = 0; $i < 5; $i++){
    echo "<div class='container'>
            <div class='games ";
    echo $namearray[$i];
    echo "'>";
    echo "</div>";
    echo "<div class='game_name'>". $gamearray[$i]. "</div>";
    echo "<div class='game_time'>". $time[$i]. " hrs</div>";
    echo "</div>\n";
}

if ($info_result->num_rows > 0){
    echo "<table>";
    echo "<th>". "ID". "</th>". "<th>". "Platform Owned". "</th>". "\n";

	while($row = $info_result->fetch_assoc()){
	    echo "<tr>";
		echo "<th>". $row["id"]. "</th>". "<th>". $row["platform_owned"]. "</th>". "\n";
	    echo "</tr>";
	}
	
	echo "</table>";
} 
else {
    echo("<a href=$transiturl>New User? Fill in your info now!</a>");
}


$o1 = passthru("python /home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/output_info.py '$userid'");

echo $o1;

/*
$file = fopen('home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/user_score_recommendation.csv', 'r');

$rg = [];
while (($line = fgetcsv($file)) !== FALSE) {
   array_push($rg, $line[1]);
}
fclose($file);

*/
echo "
</body>
</html>
";





