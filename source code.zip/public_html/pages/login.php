<!DOCTYPE html>
<html>
    <head>
       <link rel="stylesheet" href="../css/style.css">
    </head>

<body>
    <title class="signupTitle">GamerSkii</title>

    <div class="topnav">
      <a href="../index.php">Back</a>
    </div>
    <!--
        <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Sign Up</button>
    -->
<div id="id01" class="modal">
    <!--
    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    -->
    <form class="modal-content" action="confirm_login.php" method="get">
    <div class="container">
        <h2>Sign In</h2>
        
        <div class="emails">
            <a class="email"><!--<label for="email"><b></b></label>-->
                <span><input type="text" placeholder="Enter Username" name="id" required></span>
            </a>
            
            
            <a class="password"><!--<label for="psw"><b></b></label>-->
                <span><input type="password" placeholder="Enter Password" name="psw" required></span>
            </a>
            
            <a class="clearfix">
                <button type="submit" class="login_btn">Log In</button>
            </a>
        </div>
        <div class="signup2">
            <a href='signup.php'>Don't have an account yet? Create one now!</a>
        </div>
    </div>
    </form>
</div>
</body>
</html>