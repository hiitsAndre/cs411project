<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);
$userid =  $_GET["uid"];

if($userid == NULL){
    $backurl = "games.php" ;
}
else{
    $backurl = "games.php?uid=$userid" ;
}

//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$name = $_GET["name"];
$platform = $_GET["platform"];
$rating = $_GET["rating"];
mysqli_query($conn,"UPDATE ign
SET score = $rating
WHERE game = '$name' and platform = '$platform' ;");
$sql = "select * from ign where game = '$name' and platform = '$platform' ";
$result = $conn->query($sql);
// echo $name;
// echo $rating;

echo "<!DOCTYPE html>
<html>
    <head>
        <link rel='stylesheet' href='../css/style.css'>
        <style>
        table, th, td {
          border: 1px solid black;
        }
        </style>
    </head>


    <body>
        <title>Search Result</title>
    
        <div class='topnav'>
          <a href=$backurl>Back</a>
        </div>";
    
    echo "Update successful. Result is show below.\n";
    echo "<table>";
    
    echo "<th>". "Name". "</th>". "<th>". "Platform". "</th>". "<th>". "Rating". "</th>". "<th>". "Release Date". "</th>". "\n";
    
    if ($result->num_rows > 0){
    	while($row = $result->fetch_assoc()){
    	    echo "<tr>";
    		echo "<th>". $row["game"]. "</th>". "<th>". $row["platform"]. "</th>". "<th>". $row["score"]. "</th>". "<th>". $row["release_date"]. "</th>". "\n";
	        echo "</tr>";
    	}
    }
    else{
    	echo "no result\n";
    }
    
    echo "</table>";
    
    echo "</body></html>";
$conn->close();
?>