<?php

$userid = $_GET["uid"];
if($userid == NULL){
    $backurl = '../index.php';
}
else{
     $backurl = "../index.php?uid=$userid";
     
}
echo"
<!DOCTYPE html>
<html>
    <head>
       <link rel='stylesheet' href='../css/style.css'>
    </head>

<body>
    <title>GamerSkii Game Data</title>

    <div class='topnav'>
      <a href=$backurl>Back</a>
    </div>
    
    <h4>Change Game's IGN Rating</h4>
    <div class='search-container'>
    <form action='change_ratings.php' method='get'>
    <input type='hidden' name='uid' value=$userid>
      <input type='text' placeholder='name' name='name'>
      <input type='text' list='platforms' placeholder='platform' name='platform'>
      <input type='number' step=0.1 placeholder='new rating' name='rating'>
      <button type='submit'>Submit</button>
    </form>
    </div>
    
    <h4>Delete Game By Name and Platform</h4>
    <div class='search-container'>
    <form action='delete.php' moethod='get'>
    <input type='hidden' name='uid' value=$userid>
      <input type='text' placeholder='name' name='name'>
      <input type='text' list='platforms' placeholder='platform' name='platform'>
      <button type='submit'>Submit</button>
    </form>
    </div>
    <!--list of choices of game platforms-->
    <datalist id='platforms'>
        <option value='PC'>
        <option value='PS4'>
        <option value='Xbox'>
        <option value='Switch'>
    </datalist>
    
    <h4>Insert New Game</h4>
    <div class='search-container'>
    <form action='create.php' method='get'>
    <input type='hidden' name='uid' value=$userid>
      <input type='text' placeholder='name' name='name'>
      <input type='text' list='platforms' placeholder='platform' name='platform'>
      <input type='text' placeholder='publisher' name='publisher'>
      <input type='text' placeholder='ign_score' name='ign_score'>
      <input type='text' placeholder='metascore' name='metascore'>
      <input type='text' placeholder='genre' name='genre'>
      <input type='text' placeholder='launch date' name='date'>
      <button type='submit'>Submit</button>
    </form>
    </div>
    
    <h4>Search by Date</h4>
    <div class='search-container'>
    <form action='search_by_date.php' method='get'>
    <input type='hidden' name='uid' value=$userid>
      <input type='text' placeholder='Date' name='date'>
      <button type='submit'>Submit</button>
    </form>
    </div>

</body>
</html>
"
?>