<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";

//connect
$conn = new mysqli($servername, $username, $password, $dbname);

//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$name = $_GET["name"];
$userid = $_GET["uid"];
$sql = "select * from genres";
$result = $conn->query($sql);



if ($userid == NULL){
//<a href='pages/signup.php'>Sign Up</a>
echo "<!DOCTYPE html>
				<html>
				    <head>
				       <link rel='stylesheet' href='css/style.css'>
				    </head>


				<body>
				    <div class='signup'>
				        <a href='pages/login.php'>Sign in</a>
				        
				    </div>

				    <title class='mainTitle'>GamerSkii</title>


				    <div class='topnav'>
				        <a class='active' href=''#home'>Home</a>
				        <a href='pages/games.php'>Game Data</a>

				        <div class='search-container'>

				            <form action='pages/search_by_name.php' method='get'>
				              <input type='text' placeholder='Search by game name' name='name'>
				              <button type='submit'>Search</i></button>
				            </form>
				        </div>
				        <div class='search-container'>

				            <form action='pages/top10_by_genre.php' method='get'>
				              <input type='text' list='genres' placeholder='Top 10 games by genre' name='genre'>
				              <button type='submit'>Search</i></button>
				            </form>
				        </div>
								<datalist id='genres'>
									<option value='action'>";
while($row = $result->fetch_assoc()){
		echo "<option value='". $row['name']. "'>";
}

echo 			 "</datalist>
				    </div>

				</body>
				</html>
";
}



else{
    $personalurl = "pages/personal_page.php?uid=$userid";
    $recomandurl = "pages/transit_test.php?uid=$userid";
    $backurl = "../index.php?uid=$userid";
    $gamesurl = "pages/games.php?uid=$userid"; 
    echo "<!DOCTYPE html>
				<html>
				    <head>
				       <link rel='stylesheet' href='css/style.css'>
				    </head>


				<body>
				    

				    <title class='mainTitle'>Gamerskii</title>


				    <div class='topnav'>
				        <a class='active' href=''#home'>Home</a>
				        <a href=$gamesurl>Game Data</a>

				        <div class='search-container'>

				            <form action='pages/search_by_name.php' method='get'>
				            
				              <input type='text' placeholder='Search by game name' name='name'>
				              <input type='hidden' name ='uid' value =$userid>
				              <button type='submit'>Search</i></button>
				            </form>
				        </div>
				        <div class='search-container'>

				            <form action='pages/top10_by_genre.php' method='get'>
				              <input type='text' list='genres' placeholder='Top 10 games by genre' name='genre'>
				              <input type='hidden' name ='uid' value =$userid>
				              <button type='submit'>Search</i></button>
				            </form>
				        </div>
								<datalist id='genres'>
									<option value='action'>";
while($row = $result->fetch_assoc()){
		echo "<option value='". $row['name']. "'>";
}

echo 			 "</datalist>
				    </div>

				</body>
				</html>
";
echo "<br>logged in as: " . $userid."</br>";
echo "<a href=$personalurl>Personal Page</a><br>";
echo "<a href='index.php'>Logout</a>";
}


$conn->close();
?>
