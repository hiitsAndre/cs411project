#!/usr/bin/python

import sys
print 'Hello world just kidding fffffff'
print 'Argument List:', sys.argv