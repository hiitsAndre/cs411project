<?php
$servername = "localhost";
$username = "gamerskii_root";
$password = "458458shanghai";
$dbname = "gamerskii_data";
//connect
$conn = new mysqli($servername, $username, $password, $dbname);

$userid = $_GET["uid"];
//test
if ($conn->connect_error){
	die("failed". $conn->connect_error);
}

$name = $_GET["name"];

$sql = "select * from genres";
$result = $conn->query($sql);
echo "<!DOCTYPE html>
				<html>
				    <head>
				       <link rel='stylesheet' href='../css/style.css'>
				    </head>


				<body>
				    

				    <title class='mainTitle'>Gamerskii</title>


				    <div class='topnav'>
				        <a class='active' href=''#home'>Home</a>
				        <a href=''#about'>About</a>
				        <a href='#contact'>Contact</a>
				        <a href='pages/games.php'>Game Data</a>

				        <div class='search-container'>

				            <form action='pages/search_by_name.php' method='get'>
				              <input type='text' placeholder='Search by game name' name='name'>
				              <button type='submit'>Search</i></button>
				            </form>
				        </div>
				        <div class='search-container'>

				            <form action='pages/top10_by_genre.php' method='get'>
				              <input type='text' list='genres' placeholder='Top 10 games by genre' name='genre'>
				              <button type='submit'>Search</i></button>
				            </form>
				        </div>
								<datalist id='genres'>
									<option value='action'>";
while($row = $result->fetch_assoc()){
		echo "<option value='". $row['name']. "'>";
}

echo 			 "</datalist>
				    </div>

				</body>
				</html>
";
echo "<b>logged in as: " . $userid."</b>";
echo "<a href='index.php'>Logout</a>";

$conn->close();
?>
