import scrapy
from scrapy import Spider
from scrapy.selector import Selector
from scrapy.http import Request

class Game(scrapy.Item):
    title = scrapy.Field()
    link = scrapy.Field()
    release_date = scrapy.Field()
    developer = scrapy.Field()
    platform = scrapy.Field()
    metascore = scrapy.Field()
    genre = scrapy.Field()

def safe_extract(selector, xpath_query):
    val = selector.xpath(xpath_query).extract()
    return val[0].strip() if val else 'NA'

class MetacriticSpider(Spider):
    name = "metacritic"
    allowed_domains = ["metacritic.com"]
    start_urls = [
            "https://www.metacritic.com/browse/games/title"
            ]

    def parse(self, response):
        platforms = ["ps4", "xboxone", "switch", "pc", "wii-u", "3ds", "vita", "ios"]
        # platforms = ["ps3", "ps2", "xbox360", "xbox"]
        platform_links = ["https://www.metacritic.com/browse/games/release-date/new-releases/" + platform for platform in platforms]
        requests = [Request(url = URL, callback = self.parse_plat) for URL in platform_links]
        return requests

    def parse_plat(self, response):
        try:
            page_links = [response.url + "?page=" + str(i) for i in range(int(response.xpath('//li[@class="page last_page"]/a/text()').extract()[0]))]
            # page_links = [response.url + "?page=" + str(i) for i in range(int(response.xpath('//li[@class="page last_page"]/a/text()').extract()[0]))]
        except IndexError:
            page_links = [response.url]

        requests = [Request(url = URL, callback = self.parse_page) for URL in page_links]
        return requests

    def parse_page(self, response):
        game_links = ["http://metacritic.com" + postfix for postfix in response.xpath('//ol[@class="list_products list_product_condensed"]/li/div/div/a/@href').extract()]
        meta_genre = response.xpath('//div[@class="module products_module list_product_condensed_module "]/div/div/h2[@class="module_title"]/text()').extract()[0].strip()
        requests = [Request(url = URL, callback = self.parse_game) for URL in game_links]
        return requests

    def parse_game(self, response):
        sel = Selector(response, type='html')
        game = Game()
        game['title'] = safe_extract(sel, '//div[@class="product_title"]/a/h1/text()')
        game['genre'] = ",".join(sel.xpath('//li[@class="summary_detail product_genre"]/span[@class="data"]/text()').extract())
        game['link'] = response.url
        game['release_date'] = safe_extract(sel, '//li[@class="summary_detail release_data"]/span[@class="data"]/text()')
        game['developer'] = safe_extract(sel, '//li[@class="summary_detail developer"]/span[@class="data"]/text()')
        game['platform'] = safe_extract(sel, '//span[@class="platform"]/a/text()')
        game['metascore'] = safe_extract(sel, '//span[@itemprop="ratingValue"]/text()')
        yield game
