#!/usr/bin/env python
# coding: utf-8

# In[22]:

import sys
#import numpy as np
import random
import csv
from apyori import apriori

userid = sys.argv[1]

import os 
dir_path = os.path.dirname(os.path.realpath(__file__))
#print(dir_path)
# In[29]:


genre = []

with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/meta_ps4.csv') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        l = row[5]
        if l == "genre":
            continue
        if ',' in l:
            gs = l.split(',')
            for g in gs:
                if g not in genre and g != '':
                    genre.append(g)
        else:
            if l not in genre and l != '':
                genre.append(l)

f.close()

games = []
for i in range(len(genre)):
    games.append([])
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/meta_ps4.csv') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        l = row[5]
        if l == "genre":
            continue
        if ',' in l:
            gs = l.split(',')
        for i in range(len(genre)):
            if genre[i] in gs and row[0] not in games[i]:
                games[i].append(row[0])
f.close()



########################################################
## platform list for users
########################################################
platform = [] # platform for each user
with open('/home/gamerskii/user_info.csv') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        l = row[3]
        if l == "platform_owned":
            continue
        pf = []
        if ',' in l:
            gs = l.split(',')
            for g in gs:
                if g not in pf and g != '':
                    pf.append(g)
        else:
            if l not in pf and l != '':
                pf.append(l)
        platform.append(pf)
f.close()
game_plat = [] # platform of all games
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/meta_ps4.csv') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        l = row[3]
        if l == "platform":
            continue
        gp = []
        if ',' in l:
            gs = l.split(',')
            for g in gs:
                if g not in gp and g != '':
                    gp.append(g)
        else:
            if l not in gp and row[5] != '':
                gp.append(l)
        game_plat.append(gp)
f.close()
#######################################################
## platform finish
#######################################################
######################################################################
# randomly generated user data
"""users = []
for i in range(100):
    user = []
    index1 = 0
    for i in range(3):
        rnd1 = np.random.randint(0,len(games[index1]))
        game1 = games[index1][rnd1]
        if game1 not in user:
            user.append(game1)
    index2 = np.random.randint(0,len(genre))
    for i in range(2):
        rnd2 = np.random.randint(0,len(games[index2]))
        game2 = games[index2][rnd2]
        if game2 not in user:
            user.append(game2)
    users.append(user)
"""


#actual user data
users = []
user_idlist = []
user = []
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/user_played.csv') as f:
    r = csv.reader(f, delimiter = ',')
    for row in r:
        l = row[0]
        if l == 'id':
            continue
        else:
            if l not in user_idlist:
                user_idlist.append(l)
    #print(user_idlist)
f.close()

i = 0
     
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/user_played.csv') as f:
    r = csv.reader(f, delimiter = ',')
    for row in r:
        if row[0] == 'id':
            continue
        elif i < len(user_idlist):
            if row[0] == user_idlist[i]:
                user.append(row[1])
                #print(user)
            else:
                users.append(user)
                user = []
                i = i + 1
                user.append(row[1])
    users.append(user)
            
        
f.close()
#print(users)                


# In[31]:


# generate genre array for each game played by user
d = dict()

with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/meta_ps4.csv') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        game_genre = []
        l = row[5]
        if l == "genre":
            continue
        if ',' in l:
            gs = l.split(',')
            for g in gs:
                if g != '':
                    game_genre.append(g)
        else:
            if l != '':
                game_genre.append(l)
        if len(game_genre)>0:
            for i in range(len(game_genre)):
                if i == 0:
                    d[row[0]] = [game_genre[i]]
                else:
                    d[row[0]].append(game_genre[i])  
f.close()

records = []
for i in range(len(users)):
    record = []
    for game_name in users[i]:
        sortedlist = sorted(d[game_name])
        record.append(','.join(sorted(list(set(sortedlist)))))       
    records.append(record)
association_rules = apriori(records, min_support=0.030, min_confidence=0.30)  
association_results = list(association_rules)  
#print(records)


# In[32]:


result = []
for i in range(len(association_results)):
    result.append(list(association_results[i][0]))

for i in range(len(result)):
    for j in range(len(result[i])):
        result[i][j] = result[i][j].split(',')
#print(result)
for i in range(len(records)):
    for j in range(len(records[i])):
        records[i][j] = records[i][j].split(',')
#print(records)


# In[33]:


genres_list = [] #suggested genre(s) for all the users
for i in range(len(records)):
    genre_list = [] # suggested game genre(s) for each user
    for j in range(len(records[i])):
        for k in range(len(result)):
            if records[i][j] in result[k]:
                for a in result[k]:
                    if a not in genre_list:
                        genre_list.append(a)
    genres_list.append(genre_list)
    #print(genre_list)


# In[56]:


games_to_users = [] # final suggested games to user
games_genres = [] # every game with all its genres
names = []
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/meta_ps4.csv') as f:
    r = csv.reader(f, delimiter=',')

    for row in r:
        game_genres = []
        l = row[5]
        if l == "genre" or l =='':
            continue
        names.append(row[0])
        if ',' in l:
            gs = l.split(',')
            for g in gs:
                if g not in game_genres and g != '':
                    game_genres.append(g)
        else:
            if l != '':
                game_genres.append(l)
        games_genres.append(sorted(game_genres))
f.close()
for i in range(len(genres_list)):
    games_to_user = []
    for j in range(len(games_genres)):
        if games_genres[j] in genres_list[i] and names[j] not in users[i]:
            
            #newadddd
            own = 0 #flag to add games with owned platform
            for plat in platform[i]:
                if plat in game_plat[j]:
                    own = 1
                    break
            if own == 1:
            ######################################################################
                games_to_user.append(names[j])
            #newaddddd
    games_to_users.append(games_to_user)
scores = [] #score for each game
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/meta_ps4.csv') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        l = row[5]
        if l == "genre" or l =='':
            continue
        if row[2] == 'NA':
            scores.append(0)
        else:
            scores.append(int(row[2]))
f.close()

game_by_score = dict()
for i in range(len(scores)):
    game_by_score[names[i]] = scores[i]
# if user chooses rank by score
score_rank = [] # games ranked by score

for i in range(len(games_to_users)):
    recommendation = []
    dict_scored = dict()
    for item in games_to_users[i]:
        gamescore = game_by_score[item]
        dict_scored[item] = gamescore
    for key, value in sorted(dict_scored.items(), key=lambda item: item[1], reverse = True):
        recommendation.append(key)
    score_rank.append(recommendation[0:10])
#print(score_rank)
# if user chooses rank by alphabet
ab_rank = []
for i in range(len(games_to_users)):
    recommendation = []
    gameab = dict()
    # still having a rate
    for item in games_to_users[i]:
        gamescore = game_by_score[item]
        gameab[item] = gamescore
    for key in sorted(gameab.keys()):
        recommendation.append(key)
    ab_rank.append(recommendation[0:10])
#print(ab_rank)

d_result = {}
for i in range(0, len(score_rank)):
    d_result[user_idlist[i]] = score_rank[i]
#print(d_result)
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/score_recommendation.csv', mode='wb') as f:
    writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for key,value in d_result.items():
        writer.writerow([key,value])
f.close()

uid = []
user_recommend = []
result = []
for key,value in d_result.items():
    #if key == userid:
    for i in range(0,10):
        user_recommend.append(value[i])
    uid.append(key)
    result.append(user_recommend)
    user_recommend = []
    
    
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/user_score_recommendation.csv', mode='wb') as f:
    writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for i in range(0,len(result)):
        for j in range(0,len(result[0])):
            writer.writerow([uid[i],result[i][j]])
f.close()    

"""
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/score_recommendation.csv', mode='r') as f:    
    for key,value in d_result.items():
        if key == userid:
            print(key)
            print(value)
"""

#print("donedonedone")
# In[113]:




