#!/usr/bin/env python
# coding: utf-8
import sys
import random
import csv

#print 'write_to_csv'
#print 'Argument List:', sys.argv[1],sys.argv[2],sys.argv[3]

#arg1 = user id
#arg2~5 = platforms owned
platform=[]
for i in range(2,len(sys.argv)):
    platform.append(sys.argv[i])
    
p = ','.join(platform)
temp = ''

result = []
uid = ''
with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/user_score_recommendation.csv', mode='r') as f:
    r = csv.reader(f, delimiter=',')
    for row in r:
        if(sys.argv[1] == row[0]):
            uid = row[0]
            result.append(row[1])
            
f.close()


if(sys.argv[1] == uid):
    #print("10 Recommended Games For User\n")
    #for i in range(0,10):
     #   print str(i+1) + ': ' +str(result[i]) +'    '
      #  print '\n'
    
    print "<table style= 'position: relative; top: 20px;' >"
    print "<caption>10 Recommended Games For User</caption>"
    print "<th> rank </th> <th> name </th> \n"
    for i in range(0,10):
        print "<tr>"
        print "<th>"
        print str(i+1)
        print "</th>"
        print "<th>"
        print str(result[i])
        print "</th>"
        print "</tr>"
