#!/usr/bin/env python
# coding: utf-8
import sys
import random
import csv

#print 'write_to_game_played'
#print 'Argument List:', sys.argv[1],sys.argv[2],sys.argv[7],sys.argv[12]

#arg1 = user id
#arg2~6 = games played
#arg7-11 = games' platforms
#arg12-16 = played time

with open('/home/gamerskii/virtualenv/public__html_python__app/2.7/recommend_app/user_played.csv', mode='a') as f:
    writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for i in range(2,7):
        writer.writerow([sys.argv[1], sys.argv[i], sys.argv[i+5], sys.argv[i+10]])