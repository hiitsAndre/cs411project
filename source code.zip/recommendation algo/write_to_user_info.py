#!/usr/bin/env python
# coding: utf-8
import sys
import random
import csv

#print 'write_to_csv'
#print 'Argument List:', sys.argv[1],sys.argv[2],sys.argv[3]

#arg1 = user id
#arg2~5 = platforms owned
platform=[]
for i in range(2,len(sys.argv)):
    platform.append(sys.argv[i])
    
p = ','.join(platform)
temp = ''
with open('/home/gamerskii/user_info.csv', mode='a') as f:
    writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    writer.writerow([sys.argv[1], temp, temp, p])